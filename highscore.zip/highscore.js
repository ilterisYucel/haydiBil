var loadScores = function loadScores() {
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			var scores = document.getElementById("scores");
			var response = JSON.parse(this.responseText);
			if ( Number(response.count) < 10) {
				for (var i = 0; i < response.scores.length; i++) {
					if (response.scores[i].id == window.localStorage.getItem("id")) {
						scores.insertAdjacentHTML('beforeend','<p style="background-color:rgb(0,255,0);">'+(i+1)+'-\t'+response.scores[i].id+'\t'+response.scores[i].score+'</p>');
					} else {
						scores.insertAdjacentHTML('beforeend','<p>'+(i+1)+'-\t'+response.scores[i].id+'\t'+response.scores[i].score+'</p>');
					}
				}
			} else {
				for (var i = 0; i < response.topScores.length; i++) {
					scores.insertAdjacentHTML('beforeend','<p style="background-color:rgb(0,255,0);">'+(i+1)+'-\t'+response.topScores[i].id+'\t'+response.topScores[i].score+'</p>');
				}
				scores.insertAdjacentHTML('beforeend','<p>...</p>');
				for (var i = 0; i < response.scores.length; i++) {
					if (response.scores[i].id == window.localStorage.getItem("id")) {
						scores.insertAdjacentHTML('beforeend','<p style="background-color:rgb(0,255,0);">'+(response.count+i-5)+'-\t'+response.scores[i].id+'\t'+response.scores[i].score+'</p>');
					} else {
						scores.insertAdjacentHTML('beforeend','<p>'+(response.count+i-5)+'-\t'+response.scores[i].id+'\t'+response.scores[i].score+'</p>');
					}
				}
			}
		}
	};
	xhttp.open("POST","http://18.216.165.149/getHighScores");
	xhttp.setRequestHeader("Content-Type","application/json");
	xhttp.send(JSON.stringify({score:window.localStorage.getItem("score"),id:window.localStorage.getItem("id")}));
};

window.onload = function() {
	document.getElementById("legend").innerHTML="Sıralama/Kullanıcı No/Puan";
	loadScores();
};
