var images = ["aglamak.jpg","araba.jpg","elma.jpg","kosu.jpg","oyun.jpg","su.png"];
var words = ["ağlamak","araba","elma","koşu","oyun","su"];
var level = 1;

var addChar = function addChar(char,id) {
	document.getElementById("input").innerHTML += char;
	document.getElementById(id).disabled = true;
	document.getElementById(id).style.backgroundColor = "rgb(238, 130, 238)";
	
	if (document.getElementById("input").innerHTML == words[level-1]) {
		level++;
		if (level > words.length) {
			window.alert("Tebrikler!\nTüm Bölümleri Tamamladınız!");
			level = 1;
		}
		loadLevel(level);
	}
};

var reset = function reset() {
	loadLevel(level);
}

var randomChar = function randomChar() {
	var chars = "abcçdefgğhıijklmnoöprsştuüvyz";
	return chars[Math.floor(Math.random()*29)];
}

var loadLevel = function loadLevel(level_no) {
	document.getElementById("input").innerHTML = "";
	
	document.getElementById("levelTitle").innerHTML = "Bölüm " + level_no;
	
	document.getElementById("question").src = "img/"+images[level_no-1];
	
	var buttons = document.getElementById("buttons");
	buttons.innerHTML = '<button id="reset" onclick="reset();">Reset</button>';
	var tmpStr = words[level_no-1].split("").sort(function(){return 0.5-Math.random()}).join("").trim();
	var buttonWidth = buttons.offsetWidth /  5;
	document.getElementById("reset").style.width = buttonWidth * 2 + 'px';
	
	
	for (var i = 0; i < tmpStr.length; i++) {
		buttons.insertAdjacentHTML('afterbegin','<button id="'+i+'" onclick="addChar(\''+tmpStr[i]+'\',\''+i+'\');">'+tmpStr[i]+'</button>');
		document.getElementById(''+i+'').style.width = buttonWidth + 'px';
		}
		
	for (var i = tmpStr.length; i < tmpStr.length+3; i++) {
		var tmpChar = randomChar();
		document.getElementById(""+(Math.floor(Math.random()*tmpStr.length))).insertAdjacentHTML('beforebegin','<button id="'+i+'" onclick="addChar(\''+tmpChar+'\',\''+i+'\');">'+tmpChar+'</button>');
		document.getElementById(''+i+'').style.width = buttonWidth + 'px';

	}
};

window.onload = function() {
	loadLevel(level);
};
