var sentences = ["Lafla peyir gemisi yürümez.","Kelin ilacı olsa başına sürer."];
var choices = [["konuşarak başarma","yorularak başarma","çalışarak başarma"],["fakirlik","çaresizlik","bencillik"]];
var answers = ["3","2"];
var level = 1;

var testAnswer = function testAnswer(id) {
	if (id == answers[level-1]) {
		level++;
		if (level > sentences.length) {
			window.alert("Tebrikler!\nTüm Bölümleri Tamamladınız!");
			level = 1;
		}
		loadLevel(level);
	} else {
		window.alert("Yanlış yanıtladınız, tekrar deneyin.");
	}
};

var loadLevel = function loadLevel(level_no) {
	document.getElementById("levelTitle").innerHTML = "Bölüm " + level_no;
	
	document.getElementById("question").innerHTML = sentences[level_no-1];
	
	var buttons = document.getElementById("buttons");
	buttons.innerHTML = '';
	
	for (var i = 0; i < choices[level-1].length; i++) {
		buttons.insertAdjacentHTML('beforeend','<div><button onclick="testAnswer(\''+(i+1)+'\');">'+(i+1)+") "+choices[level-1][i]+'</button></div>');
	}
};

window.onload = function() {
	loadLevel(level);
};
