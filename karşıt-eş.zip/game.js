var sentences = ["Hediye (Eş Anlam)","Fakir (Karşıt Anlam)","Cömert (Eş Anlam)"];
var choices = [["madalya","vasiyet","armağan"],["fakir","zengin","dürüst"],["cimri","eli açık", "mert"]];
var answers = ["3","2","2"];
var level = 1;
var lives = 5;

var testAnswer = function testAnswer(id) {
	if (id == answers[level-1]) {
		level++;
		if (level > sentences.length) {
			vex.dialog.alert({unsafeMessage:'<p>Tebrikler!\nTüm Bölümleri Tamamladınız!</p><br><img src="win.png" alt="win">'});
			level = 1;
		}
		window.setTimeout(function(){
			vex.dialog.alert({unsafeMessage:'<p>Doğru cevap!</p><br><img src="correct.png" alt="correct">'});
			loadLevel(level);
		},3000);
	} else {
		lives--;
		if (lives <= 0) {
			vex.dialog.alert({unsafeMessage:'<p>Yanlış yanıtladınız, tüm haklarınız bitti.</p><br><img src="lose.png" alt="lose">'});
			lives = 5;
			level = 1;
		} else {
			vex.dialog.alert({unsafeMessage:'<p>Yanlış yanıtladınız, tekrar deneyin.</p><br><img src="incorrect.png" alt="incorrect">'});
		}
		loadLevel(level);
	}
};

var loadLevel = function loadLevel(level_no) {
	document.getElementById("levelTitle").innerHTML = "Bölüm " + level_no;
	
	document.getElementById("question").innerHTML = sentences[level_no-1];
	
	var buttons = document.getElementById("buttons");
	buttons.innerHTML = '';
	
	for (var i = 0; i < choices[level-1].length; i++) {
		buttons.insertAdjacentHTML('beforeend','<div><button onclick="testAnswer(\''+(i+1)+'\');">'+(i+1)+") "+choices[level-1][i]+'</button></div>');
	}
	
	var lifebar = document.getElementById("lifebar");
	lifebar.innerHTML = "";
	
	for (var i = 0; i < lives; i++) {
		lifebar.insertAdjacentHTML('beforeend','<img src="life.png" alt="1up" height="48" width="48">');
	}
};

window.onload = function() {
	loadLevel(level);
};
